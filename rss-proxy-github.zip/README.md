# RSS Proxy — GitHub Actions

Fetch automatique des flux RSS Acast toutes les heures, converti en JSON statique.

## Fichiers générés

- `public/isles-aux-enfants.json`
- `public/metzstories.json`

## Utilisation dans RssFeed.tsx

```tsx
// Îles aux enfants
<RssFeed
  url="https://raw.githubusercontent.com/TON_USERNAME/TON_REPO/main/public/isles-aux-enfants.json"
  color="#..."
/>

// Metz Stories
<RssFeed
  url="https://raw.githubusercontent.com/TON_USERNAME/TON_REPO/main/public/metzstories.json"
  color="#..."
/>
```

## Lancer manuellement

Dans GitHub → Actions → "Fetch RSS Feeds" → "Run workflow"
